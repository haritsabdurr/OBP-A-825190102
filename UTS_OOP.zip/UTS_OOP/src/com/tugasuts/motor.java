package com.tugasuts;

public class motor {

    //definisi atribut
    String brand;
    String color;
    int speed;

    //constructor
    public motor(String brand, String color, int speed){
        this.brand = brand;
        this.color = color;
        this.speed = speed;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public motor() {
        System.out.println(" Ini adalah Kondisi motor ");
        System.out.println(" ======================== ");
    }


    public void run(){
        if (speed > 100){
            System.out.println(" motorcycle is Overspeed");
        }
    }

    public void run(String brand){
        System.out.println(brand + " Is accelerating");
    }

    public void brake() {
        if (speed < 60) {
            System.out.println(" Motorcycle is Underspeed");
        }
    }

    public void brake(String brand){
        System.out.println(brand + " Is decelerating ");
    }

    public void turnLeft(){
        System.out.println(" Motorcycle is turning left");
    }

    public void turnRight(){
        System.out.println(" Motorcycle is turning right");
    }

    public void turnLeft(String brand){
        System.out.println(brand + " is turning left");
    }

    public void turnRight(String brand){
        System.out.println(brand + " is turning left");
    }


}

