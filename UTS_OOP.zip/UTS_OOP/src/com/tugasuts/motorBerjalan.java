package com.tugasuts;

public class motorBerjalan extends motor {
    private static int speed;

    public motorBerjalan(String brand, String color, int speed) {
        super(brand, color, speed);
    }

    public static void main(String[] args) {
        //membuat objek motor
        motor motor = new motor();

        //mengisi atribut dari class motor
        motor.brand = " Kawasaki ";
        motor.color = " Blazing Red ";
        motor.speed = 120;

        //memanggil isi atribut dari motor
        System.out.println(" Motorcycle brand = " + motor.brand);
        System.out.println(" Motorcylce color = " + motor.color);
        System.out.println(" Motorcyclce speed = " + motor.speed);

        //menjalankan method
        motor.run();
        motor.brake();
        
        motor.turnLeft();
        motor.turnRight();



        }

}




